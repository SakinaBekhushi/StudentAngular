export class Student {
   public first_name:String='';
   public last_name:String='';
   public email:String=''
   public password:String=''
}
